CREATE TABLE table_name (
ID int,
user_name varchar(120),
user_pass varchar(50),
); 